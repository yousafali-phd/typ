-- SQL Backup for database: typing_april_12
-- Generated: 2026-05-21 11:09:04

DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL COMMENT 'MD5 hashed',
  `full_name` varchar(200) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

DROP TABLE IF EXISTS `app_settings`;
CREATE TABLE `app_settings` (
  `skey` varchar(100) NOT NULL,
  `svalue` varchar(255) NOT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`skey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

DROP TABLE IF EXISTS `archive_logs`;
CREATE TABLE `archive_logs` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `archive_id` int unsigned NOT NULL,
  `admin_id` int unsigned DEFAULT NULL,
  `action` varchar(50) DEFAULT NULL,
  `details` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_archive_id` (`archive_id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `archives`;
CREATE TABLE `archives` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `archive_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `db_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Database name like typing_archive_Q1_2026',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int unsigned DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `size_mb` decimal(10,2) DEFAULT '0.00',
  `archived_count` int DEFAULT '0',
  `is_compressed` tinyint DEFAULT '0',
  `status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'active' COMMENT 'active, archived, deleted',
  PRIMARY KEY (`id`),
  UNIQUE KEY `archive_name` (`archive_name`),
  UNIQUE KEY `db_name` (`db_name`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_archive_name` (`archive_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Archive metadata table to track database backups and replicas';

DROP TABLE IF EXISTS `candidate_center_change_logs`;
CREATE TABLE `candidate_center_change_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `old_center_id` int NOT NULL,
  `new_center_id` int NOT NULL,
  `changed_by_role` enum('admin','incharge') NOT NULL,
  `changed_by_id` int NOT NULL DEFAULT '0',
  `reason` varchar(500) NOT NULL,
  `changed_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ccl_user` (`user_id`),
  KEY `idx_ccl_old_center` (`old_center_id`),
  KEY `idx_ccl_new_center` (`new_center_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

DROP TABLE IF EXISTS `center_incharges`;
CREATE TABLE `center_incharges` (
  `id` int NOT NULL AUTO_INCREMENT,
  `center_id` int DEFAULT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(200) NOT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_incharge_username` (`username`),
  KEY `idx_center` (`center_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb3;

DROP TABLE IF EXISTS `centers`;
CREATE TABLE `centers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `code` varchar(20) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `capacity` int DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;

DROP TABLE IF EXISTS `lab_sessions`;
CREATE TABLE `lab_sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `center_id` int NOT NULL,
  `session_password` varchar(10) NOT NULL,
  `status` enum('active','expired') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `center_id` (`center_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

DROP TABLE IF EXISTS `live_candidates`;
CREATE TABLE `live_candidates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `session_id` int NOT NULL,
  `center_id` int NOT NULL,
  `started_at` datetime NOT NULL,
  `finished_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_session` (`user_id`,`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

DROP TABLE IF EXISTS `paragraphs`;
CREATE TABLE `paragraphs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `content` text NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `type_code` tinyint(1) NOT NULL DEFAULT '1',
  `type_name` varchar(100) NOT NULL DEFAULT 'Normal',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

DROP TABLE IF EXISTS `results`;
CREATE TABLE `results` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int NOT NULL,
  `center_id` int DEFAULT NULL,
  `roll_no` varchar(20) NOT NULL,
  `characters_typed` text NOT NULL,
  `correct_words` int NOT NULL,
  `incorrect_words` int NOT NULL,
  `wpm` varchar(10) NOT NULL,
  `accuracy` varchar(10) NOT NULL,
  `time` varchar(30) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_center_id` (`center_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `retest_logs`;
CREATE TABLE `retest_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `center_id` int NOT NULL,
  `incharge_id` int NOT NULL,
  `reason` varchar(500) NOT NULL,
  `allowed_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_retest_user` (`user_id`),
  KEY `idx_retest_center` (`center_id`),
  KEY `idx_retest_incharge` (`incharge_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

DROP TABLE IF EXISTS `type_codes`;
CREATE TABLE `type_codes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_type_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `roll_no` int DEFAULT NULL,
  `cnic` bigint DEFAULT NULL,
  `tested` tinyint(1) DEFAULT '0',
  `allow_retest` tinyint(1) DEFAULT '0',
  `last_login` datetime DEFAULT NULL,
  `logged_once` tinyint(1) DEFAULT '0',
  `name` varchar(100) DEFAULT NULL,
  `fathername` varchar(100) DEFAULT NULL,
  `date` int DEFAULT NULL,
  `time` varchar(8) DEFAULT NULL,
  `post` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `wpm_required` int DEFAULT NULL,
  `project` varchar(50) NOT NULL DEFAULT '',
  `type` int NOT NULL,
  `otp` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `center_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `center_code` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `center_name` varchar(255) DEFAULT NULL,
  `image_url` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `idx_center_id` (`center_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

