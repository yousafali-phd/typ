<?php
// Database configuration - update credentials as needed
$dbHost = getenv('DB_HOST') ?: 'localhost';
$dbUser = getenv('DB_USER') ?: 'eteapro_typing';
$dbPass = getenv('DB_PASS') ?: 'yBuKz8]m3!vM';
$dbName = getenv('DB_NAME') ?: 'eteapro_typing';

$mysqli = new mysqli($dbHost, $dbUser, $dbPass, $dbName);

if ($mysqli->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $mysqli->connect_error]));
}
$mysqli->set_charset("utf8");
